#' @description
#' R Implementations of "Programs" from _Introduction to Probability_ by Grinstead and Snell.
#' @keywords internal
#' @import rlang
"_PACKAGE"
